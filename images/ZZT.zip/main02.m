clear all
clc
NB = [60
    60
    60
    60
    60
    60
    60
    60
    60
    60];
BN = [ 70
    70
    70
    70
    70
    70
    70
    70
    70
    70];
data = [NB(1),BN(1);NB(2),BN(2);NB(3),BN(3);NB(4),BN(4);NB(5),BN(5);...
        NB(6),BN(6);NB(7),BN(7);NB(8),BN(8);NB(9),BN(9);NB(10),BN(10)];

bar(data,1);

axis([0 11 0.0 100]);
xlabel('ѵ����(��)')
ylabel('�ʣ�%��')

legend('2��','3��');

set(gca,'XTickLabel',{120,240,360,480,600,720,840,960,1080,1200});

set(gcf,'color','white')

applyhatch(gcf,'\.x.');